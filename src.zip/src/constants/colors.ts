import { StyleSheet } from 'react-native';

export const Colors = {
    primary: '#58C477', 
    secondary: '#ACA6A8', 
    alert: '#E07F51', 
    background: '#f5f5f5', 
    cardBackground: '#fff',
    text: '#000000',
};